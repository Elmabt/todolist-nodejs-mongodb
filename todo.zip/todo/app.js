const express = require('express');
// här börja error 
// const TodoTask = require('./models/TodoTask');
const TodoTask  = require('./models/TodoTask');

const app  = express(); 
app.set("view engine", 'ejs');

//access to css sheet
app.use("/static", express.static("public"));
app.use(express.urlencoded({ extended: true }));

//connection till mongodb---------------------
const mongoose = require('mongoose');


let dev_db_url = 'mongodb+srv://(skriv in användarnamnet här):(skriv lösen här)@cluster0.uoqtx.mongodb.net/todo?retryWrites=true&w=majority';
let mongoDB = process.env.MONGODB_URI || dev_db_url;
mongoose.connect(mongoDB);
mongoose.Promise = global.Promise;
let db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error'));
//-----------------------

//  app.get ('/', (req, res) => {
//       res.render('todo');
//  });

   app.get('/', (req, res) => {
     TodoTask.find({}, (err, tasks) => {
         res.render('todo.ejs', { todoTasks: tasks });
     });
 });

  app.post('/', (req, res, next) => {
      var todo = new TodoTask({
          content: req.body.content,
      });
      todo.save(function(err) {
          if(err){
              return next (err);
          }
          res.redirect('/');
      });
  });


app
    .route('/edit/:id')
    // Geting selected Todo with id and render new template with
    // preselected Todo in this case  todoedit.ejs
    .get((req, res) => {
        const id = req.params.id;
        TodoTask.find({}, (err, tasks) => {
            res.render('todoEdit.ejs', { todoTasks: tasks, idTask: id });
        });
    })
    //Updating selectd Todo
    .post((req, res) => {
        const id = req.params.id;
        TodoTask.findByIdAndUpdate(id, { content: req.body.content }, (err) => {
            if (err) return res.send(500, err);
            res.redirect('/');
        });
    });
    //delete funktion 
    app.route('/delete/:id').get((req, res) =>{
        const id = req.params.id;
        TodoTask.findByIdAndRemove(id, (err) => {
            if (err){
                return nex(err);
            }
            res.redirect('/');

        });
    });




app.listen(1337, () => console.log
("Server Up and running"));
